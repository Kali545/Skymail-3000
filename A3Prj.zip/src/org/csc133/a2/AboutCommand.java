package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;

public class AboutCommand extends Command {
    private GameWorld gameAbout;

    public AboutCommand(GameWorld gw) {
        super("About Me :");
        gameAbout = gw;
    }
    @Override
        public void actionPerformed(ActionEvent event){
           // gameAbout.pause();
            Command cancelAction = new Command("Cancel");
            Command command = Dialog.show("My information","Kate Miller \n CSC 133 \n", cancelAction);

            if(command == cancelAction){
               // gameAbout.unpause();
                return;

        }
    }



}

package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;


import javax.swing.*;

class AccelerateCommand extends Command {
    private GameWorld gameAcc;

    public AccelerateCommand (GameWorld gw) {
        super("Accelerate");
        gameAcc = gw;
    }

    //tells game world to access helicopter to make it accelerate
    public void actionPerformed(ActionEvent event){
        gameAcc.accelerate();


    }



}
package org.csc133.a2;
import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;
import java.io.IOException;
import java.io.InputStream;

public class BGSound implements Runnable{

    private Media media;


    public BGSound(String fileName) {

        try {
            new Thread(this).start();
            InputStream in = Display.getInstance().getResourceAsStream(getClass(), "/" + fileName);
            media = MediaManager.createMedia(in, "audio/wav");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

  public void pause(){
    media.pause();
        }

  public void play(){
        media.play();
  }

    @Override
    public void run() {
        media.setTime(0);
        media.play();
    }
}

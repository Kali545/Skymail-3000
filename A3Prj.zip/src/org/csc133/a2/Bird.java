package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.geom.Point;

import java.io.IOException;

public class Bird extends MoveableObjects{

    Image birdImage[]= new Image[1];
    Image gameBirdImage[] = new Image[1];


    public Bird(int color) {

        setXLocation(getRandomDouble(XBoundary));
        setYLocation(getRandomDouble(YBoundary));
        setSpeed(getRandomInt(6, 5));
        setHeading(getRandomInt(359, 1));
        setMyColor(color);
        setSize(getRandomInt(30,85));

        try{
            birdImage[0]= Image.createImage("/bird1.png");
        }catch (IOException e){e.printStackTrace();}
        gameBirdImage[0] = birdImage[0];
    }
    public void setMyColor(int r, int g, int b){}

  public void draw(Graphics g, Point containerOrigin) {

      g.drawImage(gameBirdImage[0], containerOrigin.getX() + (int) this.getXLocation(),
              containerOrigin.getY() + (int) this.getYLocation(), this.getSize(),
              this.getSize());
  }
       /* int lineX = containerOrigin.getX() + (int)getXLocation();
        int lineY = containerOrigin.getY() + (int)getXLocation();

        g.setColor(this.getMyColor());
        g.drawArc(containerOrigin.getX() + (int)getXLocation() - getSize()/2, containerOrigin.getY() + (int)getYLocation() - getSize()/2, this.getSize(), this.getSize(), 0, 360);
        g.setColor(ColorUtil.GREEN);
        g.drawLine(lineX, lineY, lineX + (int)(Math.cos(Math.toRadians(90 - getHeading()))* getSize()/2), lineY + (int)(Math.sin(Math.toRadians(90-getHeading()))*getSize()/2));
         }*/


    @Override
    public boolean collidesWith(GameObject otherObject) {
        return false;
    }

    @Override
    public void handleCollision(GameObject otherObject) {

    }

}


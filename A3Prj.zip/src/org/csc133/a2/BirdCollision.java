package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Image;

public class BirdCollision extends Command {
    public BirdCollision(String command, Image icon, int id) {
        super(command, icon, id);
    }
    /*newMyColor = heli.getMyColor();
    newMyColor = ColorUtil.rgb(200, 0, 0);
    damageReport = heli.getDamageLevel() + 1;
    newSpeed = heli.getSpeed() - 1;
        System.out.print("You're gummed up from a bird!" + newMyColor*/
}

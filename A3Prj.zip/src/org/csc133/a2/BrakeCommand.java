package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Image;
import com.codename1.ui.events.ActionEvent;

public class BrakeCommand extends Command {
    private GameWorld gameBrake;

    public BrakeCommand(GameWorld gw) {
        super("");
        gameBrake = gw;
    }

    public void actionPerformed(ActionEvent event){
        gameBrake.brake();
    }
}

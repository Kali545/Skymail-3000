package org.csc133.a2;

import com.codename1.ui.*;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.charts.util.ColorUtil;
import java.io.IOException;


public class ButtonViewClass extends Container{
    public ButtonViewClass(GameWorld gw){

        Image Left = null;
        Image Right = null;
        Image Up = null;
        Image Down = null;

        try{
             Left = Image.createImage("/left.png");
             Right = Image.createImage("/right.png");
             Up = Image.createImage("/up.png");
             Down = Image.createImage("/down.png");


            //make new command objects for above buttons
            LeftCommand lc = new LeftCommand(gw);
            AccelerateCommand ac = new AccelerateCommand(gw);
            BrakeCommand bc = new BrakeCommand(gw);
            RightCommand rc = new RightCommand(gw);


            Button l = new Button(Left);
            Button r = new Button(Right);
            Button a = new Button(Up);
            Button b = new Button(Down);

            //make new key listeners for commands
            l.setCommand(lc);
            a.setCommand(ac);
            b.setCommand(bc);
            r.setCommand(rc);

            this.add(l).add(a).add(b).add(r);

            this.getAllStyles().setBgTransparency(255);
            this.getAllStyles().setBgColor(ColorUtil.BLUE);
            this.setLayout(new GridLayout(1,4));

            this.getAllStyles().setPadding(0,0,5,5);



        }catch(IOException e){e.printStackTrace();}

    }


}

package org.csc133.a2;

import com.codename1.ui.Command;

public class ChangeStrategiesCommand extends Command {
    private GameWorld gameStrategies;
    public ChangeStrategiesCommand(GameWorld gw){

    super("");
    gameStrategies = gw;
    }
}

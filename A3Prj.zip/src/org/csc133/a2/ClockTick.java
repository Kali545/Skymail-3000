package org.csc133.a2;
//not sure if this is going to be a command or just a function that is running in the background
public class ClockTick {
}

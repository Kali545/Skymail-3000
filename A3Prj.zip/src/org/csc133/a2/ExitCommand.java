package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.events.ActionEvent;

public class ExitCommand extends Command {
    GameWorld gameExit;
    public ExitCommand(GameWorld gw) {
        super("Exit Game :");
    }

    @Override
    public void actionPerformed(ActionEvent event){
        //gameExit.pause()
        Command cancel = new Command("Cancel");
        boolean isExit = Dialog.show("Exit Game?", "Select yes to quit or no to keep playing", "Yes", "No");
        if(isExit){
            Display.getInstance().exitApplication();
        }
        //gameExit.unpause();

    }
}

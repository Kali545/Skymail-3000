package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Image;

public class FuelHeliFromBlimp extends Command {
    public FuelHeliFromBlimp(String command, Image icon, int id) {
        super(command, icon, id);
    }
    /*System.out.printf("You have made it to refuel. ", BoxLayout.y());
    int fuel;
    int showHeli;
    int showBlimp; //these are testers to see my output
    fuel = Blimp1.getSize();
    showHeli = heli.setFuelLevel(fuel);
    showBlimp = Blimp1.setSize(0);
    System.out.printf("this is the helicopter fuel capacity " + showHeli + "\n");
        System.out.printf("this is the blimp fuel capacity " + showBlimp + "\n");
    */

}

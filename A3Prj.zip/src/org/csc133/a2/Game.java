
package org.csc133.a2;
//this is the controller @startuml

import com.codename1.ui.Form;
import com.codename1.ui.Toolbar;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.util.UITimer;

public class Game extends Form implements Runnable {
    private GameWorld gw;
    GlassCockpit cockpit;
    ButtonViewClass buttonView;

    MapView gameMap;
    private UITimer gameTimer;

    private GameClockComponent gameTimeController;

    public Game() {
        gw = new GameWorld();
        gameMap = new MapView(gw);
        cockpit = new GlassCockpit(gw);
        buttonView = new ButtonViewClass(gw);
        gameTimer  = new UITimer(this);
        gameTimeController = new GameClockComponent(gw);

        //instantiate command objects
        AccelerateCommand accel = new AccelerateCommand(gw);
        BrakeCommand brake = new BrakeCommand(gw);
        LeftCommand left = new LeftCommand(gw);
        RightCommand right = new RightCommand(gw);
        AboutCommand about = new AboutCommand(gw);
        HelpCommand help = new HelpCommand(gw);
        StrategyCommand strat = new StrategyCommand(gw);
        ExitCommand exit = new ExitCommand(gw);




        //add key listener
        addKeyListener('a', accel);
        addKeyListener('b', brake);
        addKeyListener('l', left);
        addKeyListener('r', right);

        //this is for the score header
        this.setLayout(new BorderLayout());

        //this sets the header to the top of the screen
        this.add(BorderLayout.NORTH, cockpit);
        this.add(BorderLayout.CENTER, gameMap);
        this.add(BorderLayout.SOUTH, buttonView);


        //this is for the title
        this.setTitle("SkyMail 3000");

        //set up side menu bar
        Toolbar menuBar = new Toolbar();
        setToolbar(menuBar);
        Toolbar.setOnTopSideMenu(true);
       // menuBar.addComponentToRightSideMenu(new Label(" "));


        //add side menu
        menuBar.addCommandToRightSideMenu(help);
        menuBar.addCommandToRightSideMenu(about);
        menuBar.addCommandToRightSideMenu(exit);
        menuBar.addCommandToRightSideMenu(strat);


        //shows header
        this.show();
        gameTimer.schedule(20,true,this);
        gw.init(gameMap);
    }

//this will pause the game
    public void pause() { //this will pause the game
        gameTimeController.stopElapsedTime();
    }

    //this will unpause the game
    public void unPause() { //this will unpause
        gameTimeController.startElapsedTime();
    }

        public void run () {
            gw.clockTick(gameMap);
        }

    }


















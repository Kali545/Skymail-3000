package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.geom.Dimension;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class GameClockComponent extends Component {
    private int ledColor;
    private int dotLedColor; //for the millisecond digit

    private static final int numDigits = 6;
    private static final int HM_COLON_INDEX = 2;

    Image dotGameClockDigits[] = new Image[10]; //for numbers with dots
    Image regClockDigit[] = new Image[10]; // for regular numbers
    Image[] clockDigits = new Image[numDigits]; //for clock dislay
    Image colon;
    Image dotNum;


    private GameClockComponent gameClock;
    private GameWorld gameWorld;

    private long startTimeInMili;
    private long startPauseTime;
    private long totalPausedTime;
    private long elapsed;




    public GameClockComponent(GameWorld gw) { //constructor
        try {
            regClockDigit[0] = Image.createImage("/LED_digit_0.png");
            regClockDigit[1] = Image.createImage("/LED_digit_1.png");
            regClockDigit[2] = Image.createImage("/LED_digit_2.png");
            regClockDigit[3] = Image.createImage("/LED_digit_3.png");
            regClockDigit[4] = Image.createImage("/LED_digit_4.png");
            regClockDigit[5] = Image.createImage("/LED_digit_5.png");
            regClockDigit[6] = Image.createImage("/LED_digit_6.png");
            regClockDigit[7] = Image.createImage("/LED_digit_7.png");
            regClockDigit[8] = Image.createImage("/LED_digit_8.png");
            regClockDigit[9] = Image.createImage("/LED_digit_9.png");

            dotGameClockDigits[0] = Image.createImage("/LED_digit_0_with_dot.png");
            dotGameClockDigits[1] = Image.createImage("/LED_digit_1_with_dot.png");
            dotGameClockDigits[2] = Image.createImage("/LED_digit_2_with_dot.png");
            dotGameClockDigits[3] = Image.createImage("/LED_digit_3_with_dot.png");
            dotGameClockDigits[4] = Image.createImage("/LED_digit_4_with_dot.png");
            dotGameClockDigits[5] = Image.createImage("/LED_digit_5_with_dot.png");
            dotGameClockDigits[6] = Image.createImage("/LED_digit_6_with_dot.png");
            dotGameClockDigits[7] = Image.createImage("/LED_digit_7_with_dot.png");
            dotGameClockDigits[8] = Image.createImage("/LED_digit_8_with_dot.png");
            dotGameClockDigits[9] = Image.createImage("/LED_digit_9_with_dot.png");

            colon = Image.createImage("/LED_colon.png");

        } catch (IOException e) {
            e.printStackTrace();
        }
        gameWorld = gw;

        for (int i = 0; i < numDigits; i++) {//sets all to 0, to make sure not null
            clockDigits[i] = regClockDigit[0];

            clockDigits[HM_COLON_INDEX] = colon; //represent colon

            ledColor = ColorUtil.CYAN; //color of numbers
            dotLedColor = ColorUtil.BLUE;//color of millisecond

            startTimeInMili = System.currentTimeMillis(); //sets start time in miliseconds
            dotNum = dotGameClockDigits[0];
        }
    }

    public void setTime() {
       int minutes = (int) (TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - startTimeInMili)%60);
       int seconds = (int) (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()-startTimeInMili)%60);
       int millis = (int) (TimeUnit.MILLISECONDS.toMillis(System.currentTimeMillis()-startTimeInMili)/100);




        clockDigits[0] = regClockDigit[minutes/10];
        clockDigits[1] = regClockDigit[minutes % 10];
        clockDigits[3] = regClockDigit[seconds/10];
        clockDigits[5] = regClockDigit[millis%10];
        clockDigits[4] = dotGameClockDigits[seconds%10];
    }



    public void resetElapsedTime(){
            totalPausedTime = 0;
            startPauseTime = 0;
            startTimeInMili = System.currentTimeMillis();
            elapsed = 0;
    }

    public void startElapsedTime(){
        if(startTimeInMili == 0){
            startTimeInMili = System.currentTimeMillis();
        }
        else if(startTimeInMili != 0){
            totalPausedTime += System.currentTimeMillis() - startTimeInMili;
        }
    }


    public void stopElapsedTime(){
        startTimeInMili = System.currentTimeMillis();
    }

    public long getElapsedTime(){
        return elapsed - startTimeInMili - totalPausedTime;

    }

    //this will change the background when time = 10 min
    public void changeRedAtTenMinutes(){

    }
    public GameClockComponent getGameClock(){
        return gameClock;
    }
    public void setLedColor(int ledColor, int dotLedColor ) {
    this.ledColor =ledColor;
    this.dotLedColor = dotLedColor;
    }

    public void startClockComponent(){
        getComponentForm().registerAnimated(this);
    }

    public void stopClockComponent() {
        getComponentForm().deregisterAnimated(this);
    } //renamed this so it wasn't confused with the other start method in AppMain

    public void laidOut() {
        this.startClockComponent(); //this starts the clock only need to call start once
    }
    //registers the form after call start

    public boolean animate() { //updates current time
        //do i need to add something for elapsed time?
        elapsed = System.currentTimeMillis() - startTimeInMili;
        setTime();
        return true;
    }

    protected Dimension calcPreferredSize() { //depends on layout using in our form
        return new Dimension(colon.getWidth() * numDigits, colon.getHeight());
    }//what size would you like to make the component?
    //how big do we make the component --> area that is this size


    public void paint(Graphics g){
        super.paint(g); //parent paint method
        final int COLOR_PAD = 1; //avoid bleed over, current rectangle slightly smaller images of clock

        int digitWidth = clockDigits[0].getWidth(); //makes digit width size of one digit
        int digitHeight = clockDigits[0].getHeight();
        int clockWidth = numDigits* digitWidth;
        float scaleFactor = Math.min(
                getInnerHeight()/(float)digitHeight, // finds inner height
                getInnerWidth()/(float)clockWidth);


        int displayDigitWidth = (int) (scaleFactor*digitWidth);
        int displayDigitHeight = (int) (scaleFactor*digitHeight);
        int displayClockWidth = displayDigitWidth*numDigits;

        int displayX = getX() + (getWidth() - displayClockWidth)/2;
        int displayY = getY() + (getHeight() - displayDigitHeight)/2;

        g.setColor(ColorUtil.BLACK);
        g.fillRect(getX(), getY(), getWidth(), getHeight());

       g.setColor(ledColor);

      g.fillRect(displayX+COLOR_PAD,
                displayY+COLOR_PAD,
                displayClockWidth-COLOR_PAD*2,
                displayDigitHeight-COLOR_PAD*2);

       for(int digitIndex = 0; //works through images to draw it
            digitIndex < numDigits - 1;
            digitIndex++) {
           g.drawImage
                   (clockDigits[digitIndex],
                           displayX + digitIndex * displayDigitWidth,
                           displayY,
                           displayDigitWidth,
                           displayDigitHeight);
       }
       g.setColor(dotLedColor);
           g.fillRect(displayX+ (displayDigitWidth*5),displayY, displayDigitWidth,
                   displayDigitHeight);
           g.drawImage(clockDigits[numDigits -1], displayX+5*displayDigitWidth, displayY, displayDigitWidth,displayDigitHeight);

    }
    }



package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;

import java.util.ArrayList;
import java.util.Random;
import java.lang.Math;
import com.codename1.ui.geom.Rectangle;

abstract class GameObject implements IDrawable, ICollider {
    final double XBoundary;
    final double YBoundary;
    Random random = new Random();

    private int size;
    private int myColor;
    private int newColor;

    private double XLocation; //this is the x-axis location of object
    private double YLocation; //this is the y-axis location of object

    private ArrayList<GameObject> objectsColliding = new ArrayList<GameObject>();

    public GameObject() {
        size = 0;
        XBoundary = 1125.0;
        YBoundary = 1723.0;

        XLocation = getRandomDouble(XBoundary);
        YLocation = getRandomDouble(YBoundary);
    }

    public ArrayList<GameObject> getObjectsColliding() {
        return objectsColliding;

    }

    //will generate a random integer number
    public int getRandomInt(int max, int min) {
        return max + random.nextInt(min++);
    }

    //made these to save code, will generate a random double for x and locations
    public double getRandomDouble(double min) {
        return Math.round(min++ * random.nextDouble());
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getMyColor() {
        return myColor;
    }

    public void setMyColor(int myColor) {
        this.myColor = myColor;
    }

    public void changeColor(int color) {
        myColor = newColor;
    }


    public void setMyDefaultColor(int myColor) {
        this.myColor = myColor;
    }

    //this will set the location of each GameObject

    public void setXLocation(double XLocation) {
        this.XLocation = XLocation;

    }

    public void setYLocation(double YLocation) {
        this.YLocation = YLocation;
    }

    public double getXLocation() {
        return this.XLocation;
    }

    public double getYLocation() {
        return this.YLocation;
    }

    public String toString() {
        String description = "location = " + XLocation + "," + YLocation + " " + "color = [" + ColorUtil.red(myColor) + "," +
                ColorUtil.green(myColor) + ColorUtil.blue(myColor) + "]" + "size = " + size;
        return description;
    }

    public Rectangle getBoundingRectangle(){
        return new Rectangle((int) getXLocation(), (int)getYLocation(), getSize(), getSize());
    }

    @Override
    public boolean collidesWith(GameObject otherObject) {
        if (this == otherObject){
            return false;
    }
        return this.getBoundingRectangle().intersects(otherObject.getBoundingRectangle());

    }


    @Override
    public void handleCollision(GameObject otherObject) {
      //  otherObject.objectsColliding(this);



    }
}

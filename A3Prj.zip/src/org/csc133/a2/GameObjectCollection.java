package org.csc133.a2;

import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


public class GameObjectCollection extends ArrayList<GameObject> {
    public GameObjectCollection() {

    }
}

 /*  private ArrayList<GameObject> objectCollection;
    private ArrayList<Bird> birdCollection;
    private ArrayList<SkyScraper> skyScraperCollection;
    private ArrayList<RefuelingBlimp> blimpCollection;
    private ArrayList<NonPlayerHelicopter> nonPlayerHelicoptersCollection;
    private GameWorld g;
   g = gw;
    objectCollection = new ArrayList<GameObject>();
    birdCollection = new ArrayList<Bird>();
    nonPlayerHelicoptersCollection = new ArrayList<NonPlayerHelicopter>();
    skyScraperCollection = new ArrayList<SkyScraper>();
    blimpCollection = new ArrayList<RefuelingBlimp>();

     skyScraperCollection.add(new SkyScraper(1,))
            birdCollection.add(new Bird(40, g.getXLocation(), g.getYLocation(), 0, 0, 0));
            birdCollection.add(new Bird(40, g.getXLocation(), g.getYLocation(), 0, 0, 0));
            skyScraperCollection.add(new SkyScraper(30, g.getXLocation(), g.getYLocation(), 0 ));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 1));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 2));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 3));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 4));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 5));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 6));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 7));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 8));
            skyScraperCollection.add(new SkyScraper(30,g.getXLocation(), g.getYLocation(), 9));
}

   public GameObjectCollection(GameWorld gw) {


        public int getNumOfSky(){
        return skyScraperCollection.size();
        }

       public SkyScraper getNumSkyScraper(int sequenceNumber){
        return  skyScraperCollection.get(sequenceNumber);

        }

        @Override
        public int size () {
            return objectCollection.size();
        }

        @Override
        public boolean isEmpty () {
            return objectCollection.isEmpty();
        }

        @Override
        public boolean contains (Object o){
            return objectCollection.contains(o);
        }

        @Override
        public Iterator<GameObject> iterator () {
            return objectCollection.iterator();
        }

        @Override
        public Object[] toArray () {
            return objectCollection.toArray();
        }

        @Override
        public <T > T[]toArray(T[]a){
            return null;
        }

        @Override
        public boolean add (GameObject gameObject){
            return objectCollection.add(gameObject);
        }

        @Override
        public boolean remove (Object o){
            return objectCollection.remove(o);
        }

        @Override
        public boolean containsAll (Collection < ? > c){
            return this.objectCollection.containsAll(c);
        }

        @Override
        public boolean addAll (Collection < ? extends GameObject > c){
            return this.objectCollection.addAll(c);
        }

        @Override
        public boolean removeAll (Collection < ? > c){
            return this.objectCollection.removeAll(c);
        }

        @Override
        public boolean retainAll (Collection < ? > c){
            return this.objectCollection.retainAll(c);
        }

        @Override
        public void clear () {
            objectCollection = new ArrayList<>();
        }

        public GameObject get ( int gameObjectIndex){
            return objectCollection.get(gameObjectIndex);
        }

    public void draw(Graphics g, Point point) {
    }


}*/
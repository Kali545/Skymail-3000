package org.csc133.a2;
//this is the data model
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import java.util.ArrayList;


public class GameWorld extends GameObject implements IDrawable {
    private int lives = 3;
    private int newSpeed = 0;


    private final GameObjectCollection gameObjects;
    private MapView gameMap;
    private ArrayList<Bird> birdies;
    private ArrayList<SkyScraper> skyScrapies;
    private ArrayList<RefuelingBlimp> blimpies;
    private ArrayList<NonPlayerHelicopter> nonPlayerHelies;

    private Helicopter helicopter;
    private int numBirds = 5;
    private int numScrapers = 10;
    private int numBlimps = 10;
    private int numNPH = 3;


    private BGSound backgroundSound;
    private boolean isPaused = false;


    public GameWorld() {
        gameObjects = new GameObjectCollection();
        backgroundSound = new BGSound("backgroundMusic.wav");

    }

    //this is where I initialize the world
    public void init(MapView mapObj) {
        gameMap = mapObj;

        birdies = new ArrayList<Bird>();
        skyScrapies = new ArrayList<SkyScraper>();
        blimpies = new ArrayList<RefuelingBlimp>();
        nonPlayerHelies = new ArrayList<NonPlayerHelicopter>();


        // add the birds
        for (int i = 0; i < numBirds; i++) {
            birdies.add(new Bird(ColorUtil.rgb(255, 153, 51)));
        }
        for(int i = 0; i < birdies.size()- 1; i++){
            gameObjects.add(birdies.get(i));
        }

        //add the skyscrapers
        for(int i = 0; i < numScrapers; i++){
            skyScrapies.add(new SkyScraper(150, i));
        }
        for(int i = 0; i < skyScrapies.size(); i++){
            gameObjects.add(skyScrapies.get(i));
        }

        //add the blimps
        for(int i = 0; i < numBlimps; i++){
            blimpies.add(new RefuelingBlimp());
        }

        for(int i = 0; i < blimpies.size(); i++){
            gameObjects.add(blimpies.get(i));
        }
        //add player's helicopter
        helicopter = new Helicopter(150,skyScrapies.get(0).getXLocation(),skyScrapies.get(0).getYLocation());
        gameObjects.add(helicopter);

        //add non player helicopters
        for(int i = 0; i < numNPH; i++){
            nonPlayerHelies.add(new NonPlayerHelicopter(50, skyScrapies.get(9).getXLocation(),skyScrapies.get(9).getYLocation()));
        }
        for(int i = 0; i < nonPlayerHelies.size(); i++){
            gameObjects.add(nonPlayerHelies.get(i));

        }

            backgroundSound.play();

    }

    //this will return a collection list to MapView
    public GameObjectCollection getGameObjectCollectionList(){

        return gameObjects;
    }

        public void clockTick (MapView gameMap) {
            if (!isPaused) {

                for (int j = 0; j < gameObjects.size(); j++) {
                    //if movable objects, move them
                    if (gameObjects.get(j) instanceof MoveableObjects) {
                        ((MoveableObjects) gameObjects.get(j)).moveObjects(gameMap);
                    }
                    for(int k = 0; k < gameObjects.size(); k++){
                        if(gameObjects.get(j) != gameObjects.get(k)){
                            if(gameObjects.get(j).collidesWith(gameObjects.get(k))){
                                gameObjects.get(j).handleCollision(gameObjects.get(k));
                            }
                        }
                    }

                }
                    gameMap.update();
            }
        }
        public void accelerate () {
            helicopter.accelerate(5); //hardcode 5 as default
        }

        @Override
        public void draw (Graphics g, Point containerOrigin){

        }


        void brake () {
                helicopter.brake(5);
            }

        void turnLeft () {
            helicopter.turnLeft(5); //I will fix later
        }

        void turnRight () {
            helicopter.turnRight(-5); //fix later
        }


    @Override
    public boolean collidesWith(GameObject otherObject) {
        return false;
    }

    @Override
    public void handleCollision(GameObject otherObject) {

    }
}



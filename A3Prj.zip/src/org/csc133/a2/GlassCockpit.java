package org.csc133.a2;

import com.codename1.ui.*;
import com.codename1.ui.layouts.GridLayout;
import java.io.IOException;

public class GlassCockpit extends Container {
     private GameClockComponent gameClock;
     private HeadingComponenet heading;
     private FuelComponent fuel;
     private DamageComponent damage;

     public GlassCockpit(GameWorld gw) {


          //public void showScore() {
          this.setLayout(new GridLayout(2, 6));
          Label scoreBoard[] = new Label[6];

          //this is the array to hold the scoreboard
          scoreBoard[0] = new Label("Game Time");
          scoreBoard[1] = new Label("Fuel");
          scoreBoard[2] = new Label("Damage");
          scoreBoard[3] = new Label("Lives");
          scoreBoard[4] = new Label("Last");
          scoreBoard[5] = new Label("Heading");

          for(int i = 0; i < scoreBoard.length; i++){
               scoreBoard[i].setAutoSizeMode(true);
               scoreBoard[i].setMaxAutoSize((float)1.0);
               scoreBoard[i].setMinAutoSize((float)1.0);
          }

          //add titles to components
          this.add(scoreBoard[0]).
                  add(scoreBoard[1])
                  .add(scoreBoard[2])
                  .add(scoreBoard[3])
                  .add(scoreBoard[4]).
                  add(scoreBoard[5]);

          gameClock = new GameClockComponent(gw);

          this.add(gameClock)
                 .add(new FuelComponent(gw))
                 .add(new DamageComponent(gw))
                  .add(new LivesComponent(gw))
                  .add(new LastSkyScraperComponent(gw))
                  .add(new HeadingComponenet(gw));
     }

     //this will update with each clock tick
     public void update(){

     }

     }





    /*void showDisplay () {

       System.out.print("You have " + lives + " lives left.");
        System.out.print("The clock has elapsed " + clock + " ticks.");
        currentScraper = heli.getLastSkyScraperReached();
        System.out.print("You currently passed # " + currentScraper);
        currentFuel = heli.getFuelLevel();
        System.out.print("You have " + currentFuel + " units of fuel left.");
        damageReport = heli.getDamageLevel();
        System.out.print("You have " + damageReport + " units of damage.\n");
        int heliSpeed = heli.getSpeed();
        System.out.print("You are currently going " + heliSpeed);*/






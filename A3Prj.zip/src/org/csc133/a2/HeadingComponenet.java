package org.csc133.a2;

import com.codename1.ui.Component;
import com.codename1.ui.Image;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.geom.Dimension;
import java.io.IOException;

public class HeadingComponenet extends Component {
    private int ledColor;
    private static final int numDigits = 3;

    //this is an array for all the different possible digits
    Image digits[] = new Image[10];

    //this array for the heading display
    Image headingDigits[] = new Image[3];

   // HeadingComponenet headingDisplay;


    public HeadingComponenet(GameWorld gw) {
        try {
            digits[0] = Image.createImage("/LED_digit_0.png");
            digits[1] = Image.createImage("/LED_digit_1.png");
            digits[2] = Image.createImage("/LED_digit_2.png");
            digits[3] = Image.createImage("/LED_digit_3.png");
            digits[4] = Image.createImage("/LED_digit_4.png");
            digits[5] = Image.createImage("/LED_digit_5.png");
            digits[6] = Image.createImage("/LED_digit_6.png");
            digits[7] = Image.createImage("/LED_digit_7.png");
            digits[8] = Image.createImage("/LED_digit_8.png");
            digits[9] = Image.createImage("/LED_digit_9.png");
        } catch (IOException e) {
            e.printStackTrace();
        }

        //initiate to zero to test first
        for (int i = 0; i < numDigits; i++) {//sets all to 0, to make sure not null
            headingDigits[i] = digits[0];
            ledColor = ColorUtil.CYAN; //color of numbers
        }
    }
            //this will set the heading of objects
            public void setCurrentHeadingDirection() {
            headingDigits[0] = digits[0];
            headingDigits[1] = digits[1];
            headingDigits[2] = digits[2]; //I need to figure out to display degrees
            }

            public void setLedColor ( int ledColor){
                this.ledColor = ledColor;
            }

            public void startHeadingComponent () {
                getComponentForm().registerAnimated(this);
            }

            public void stopHeadingComponent () {
                getComponentForm().deregisterAnimated(this);
            } //renamed this so it wasn't confused with the other start method in AppMain

            public void laidOut () {
                this.startHeadingComponent(); //this starts the clock only need to call start once
            }
            //registers the form after call start

            public boolean animate () {
               setCurrentHeadingDirection(); //this will set the heading
                return true;
            }

            protected Dimension calcPreferredSize () { //depends on layout using in our form
                return new Dimension( digits[0].getWidth() * numDigits, digits[0].getHeight());
            }


            public void paint (Graphics g){
                super.paint(g); //parent paint method
                final int COLOR_PAD = 1; //avoid bleed over, current rectangle slightly smaller images of clock

                int digitWidth = headingDigits[0].getWidth(); //makes digit width size of one digit
                int digitHeight = headingDigits[0].getHeight();
                int clockWidth = numDigits * digitWidth;

                float scaleFactor = Math.min(
                        getInnerHeight() / (float) digitHeight, // finds inner height
                        getInnerWidth() / (float) clockWidth);

                int displayDigitWidth = (int) (scaleFactor * digitWidth);
                int displayDigitHeight = (int) (scaleFactor * digitHeight);
                int displayClockWidth = displayDigitWidth * numDigits;

                int displayX = getX() + (getWidth() - displayClockWidth) / 2;  //centers clock
                int displayY = getY() + (getHeight() - displayDigitHeight) / 2;

                g.setColor(ColorUtil.BLACK);
                g.fillRect(getX(), getY(), getWidth(), getHeight());
                g.setColor(ledColor);
                g.fillRect(displayX + COLOR_PAD,
                        displayY + COLOR_PAD,
                        displayClockWidth - COLOR_PAD * 2,
                        displayDigitHeight - COLOR_PAD * 2);
                for (int digitIndex = 0; //works through images to draw it
                     digitIndex < numDigits;
                     digitIndex++) {
                    g.drawImage
                            (headingDigits[digitIndex],
                                    displayX + digitIndex * displayDigitWidth,
                                    displayY,
                                    displayDigitWidth,
                                    displayDigitHeight);
                }
            }

        }


package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Dialog;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.geom.Point;
import com.codename1.ui.Transform;

import java.io.IOException;

class Helicopter extends MoveableObjects implements ISteerable {

    private int stickAngle; //can change at most 40 no more than 5 each tick
    private int maximumSpeed = 10;  //the fastest the heli can go
    private int fuelLevel;  //fuel left
    private int maxFuelLevel;
    private int fuelConsumptionRate = 5; //how much heli uses each clock tick
    private int damageLevel = 0;   //how much damage heli has
    private int maxDamageAllowed = 100; //This is the maximum damage allowed before loses game
    protected int lastSkyScraperReached = 0;  //updates after heli passes each sky scraper
    private int placeholder; //holds value so i can can subtract percentage of damage lost

    private int minSpeed = 0;
    private int heliDamageSpeed = 2;
    private int birdDamageSpeed = 1;

  //  public Sound heliHeliCrashSound;



    private GameWorld gw;
    Image heliImage[] = new Image[2]; //this will be with no damage
    Image gameHeliImage[] = new Image[2];

    Image heliDamageImage[] = new Image[4]; //this will be incremental damage
    Image gameDamageHeliImage[] = new Image[4];


    public Helicopter(int size, double x, double y){
        setSize(size);
        maxFuelLevel = 500;
        fuelLevel = maxFuelLevel;
        stickAngle = 0;
        setSpeed(3);
        setHeading(0);
        gw = new GameWorld();
       // heliHeliCrashSound = new Sound("crash.wav");
        try{
            heliImage[0] = Image.createImage("/helicopter1.png");
        }catch (IOException e){e.printStackTrace();}
            gameHeliImage[0] = heliImage[0];
    }

    int myColor = ColorUtil.rgb(0, 255, 0); //helicopters are red


    private void damageSpeed(int damageLevel, int maxDamageAllowed, int speed){ //this method adjusts speed based on damage level
        if(damageLevel == maxDamageAllowed){
            // lives--; //subtract lives
        }
        else
            placeholder = speed * (damageLevel/maxDamageAllowed);
        speed = speed - placeholder;//this finds the percentage of damage and applies to speed
    }

    public int getStickAngle() {
        return this.stickAngle;
    }

    public int getMaximumSpeed() {
        return this.maximumSpeed;
    }

    public int getFuelLevel() {
        return this.fuelLevel;
    }

    public int setFuelLevel(int fuel){ //this will set the fuel level to the blimp's fuel level
        fuelLevel = fuel + fuelLevel;
        return fuelLevel;
    }

    public int getFuelConsumptionRate() {
        return this.fuelConsumptionRate;
    }

    public int getDamageLevel() {
        return this.damageLevel;
    }

    public int getMyColor(){ return this.myColor;
    }

    public void setMyColor(int newColor){
        this.myColor = newColor; //this will change the color need to change this somehow
    }

    public void accelerate(int newSpeed) {
        if(getSpeed() + newSpeed <= maximumSpeed){
            setSpeed(getSpeed()+ newSpeed);
            System.out.println("You've accelerated. Your speed is" + getSpeed());
        }
        else {
            setSpeed(getMaximumSpeed());
            System.out.printf("You are going the max speed" + getSpeed());
            // System.out.print("You've accelerated " + newSpeed +"\n");
        }
    }

    //this will be called by the GameWorld
    public  void brake(int newSpeed) {
            if(getSpeed()<= minSpeed){
                System.out.println("You're not moving!" + getSpeed());
                setSpeed(0);
            }
            else{
                setSpeed(getSpeed() - newSpeed);
                System.out.println("Your new speed is " + getSpeed());
            }

        }


    //this will turn heli 5 degrees left
    public void turnLeft(int newHeading){
            turnCyclicStickLeft(newHeading);
            setHeading(getHeading() + newHeading);
            System.out.print("You are turning left 5 degrees " + newHeading+ "\n");
            System.out.println("Your current heading " + getHeading());
    }

    //this will turn the heli 5 degrees right
    public void turnRight(int newHeading){
        turnCyclicStickRight(newHeading);
        setHeading(getHeading() + newHeading);
        System.out.print("You are turning right 5 degrees " + getHeading());
    }

    @Override
    public void turnCyclicStickRight(int number) {
        int turnAngle = stickAngle - number;
        if(turnAngle >= 40){
            System.out.println("That's as far right as the stick will go!");
        }
        else
             stickAngle = turnAngle;
             System.out.println("Helicopter stick is angled 5 degrees right");
    }
    @Override
    public void turnCyclicStickLeft(int number){
        int turnAngle = stickAngle - number;
        if(turnAngle <= -40){
            System.out.println("That's as far as the stick will go left!");
        }
        else
            stickAngle = turnAngle;
            System.out.println("Helicopter stick is angled 5 degrees left");
    }

    @Override
    public void draw(Graphics g, Point containerOrigin) {

    g.drawImage(gameHeliImage[0], containerOrigin.getX() + (int)this.getXLocation(),
            containerOrigin.getY() + (int) this.getYLocation(), this.getSize(),this.getSize());
    }

   //this will handle all the different types of collisions


    @Override
    public boolean collidesWith(GameObject otherObject) {
        if (this == otherObject){
            return false;
        }
        return this.getBoundingRectangle().intersects(otherObject.getBoundingRectangle());

    }

    @Override
    public void handleCollision(GameObject otherObject) {
            if(otherObject instanceof Helicopter){
                damageLevel = damageLevel + 2; //adds two as the damage inflicted
                setSpeed(getSpeed() - heliDamageSpeed);
                //heliHeliCrashSound.play();
                System.out.print("It looks like you hit another helicopter"+ damageLevel + "\n");
            }
            else if(otherObject instanceof Bird){
                damageLevel = damageLevel + 1;
                setSpeed(getSpeed() - birdDamageSpeed);
                System.out.print("You're gummed up from a bird!"  + damageLevel + "\n");
            }

            else if(otherObject instanceof SkyScraper){
                if((((SkyScraper) otherObject).getSequenceNumber() == (lastSkyScraperReached + 1))) {
                    lastSkyScraperReached++;
                }
            }else if(otherObject instanceof RefuelingBlimp){
                fuelLevel = fuelLevel + ((((RefuelingBlimp) otherObject).getSize()));
                System.out.println("You have refueled! " + fuelLevel + "\n");


            }
        }

    }






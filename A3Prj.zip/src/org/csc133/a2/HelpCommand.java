package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;

public class HelpCommand extends Command {
    private GameWorld gameHelp;
    public HelpCommand(GameWorld gw){
        super("Get Help: ");
    }

    @Override
    public void actionPerformed(ActionEvent event){
        //gameHelp.pause();
        Command cancelAction = new Command("Cancel");
        Command command = Dialog.show("Game Commands", "Accelerate a\n Brake b\n Right r\n Left l\n", cancelAction);


    }
}


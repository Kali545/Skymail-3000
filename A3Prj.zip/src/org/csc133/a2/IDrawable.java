//@startuml
package org.csc133.a2;

import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public interface IDrawable {

    public void draw(Graphics g, Point containerOrigin);


}
//@enduml

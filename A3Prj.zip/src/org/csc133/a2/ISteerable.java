package org.csc133.a2;

public interface ISteerable {
    public void turnCyclicStickRight(int howMuch);
    public void turnCyclicStickLeft(int howMuch);
}

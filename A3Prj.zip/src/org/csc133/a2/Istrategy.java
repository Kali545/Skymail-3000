package org.csc133.a2;

public class Istrategy {
}

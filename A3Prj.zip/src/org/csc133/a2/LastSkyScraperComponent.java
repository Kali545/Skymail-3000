package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.geom.Dimension;

import java.io.IOException;

public class LastSkyScraperComponent extends Component {
    private int ledColor;
    private static final int numSkyDigits = 1;


    Image sDigits[] = new Image[10];
    Image SkyDigits[] = new Image[1];

    public LastSkyScraperComponent(GameWorld gw) {
        try {
            sDigits[0] = Image.createImage("/LED_digit_0.png");
            sDigits[1] = Image.createImage("/LED_digit_1.png");
            sDigits[2] = Image.createImage("/LED_digit_2.png");
            sDigits[3] = Image.createImage("/LED_digit_3.png");
            sDigits[4] = Image.createImage("/LED_digit_4.png");
            sDigits[5] = Image.createImage("/LED_digit_5.png");
            sDigits[6] = Image.createImage("/LED_digit_6.png");
            sDigits[7] = Image.createImage("/LED_digit_7.png");
            sDigits[8] = Image.createImage("/LED_digit_8.png");
            sDigits[9] = Image.createImage("/LED_digit_9.png");
        } catch (IOException e) {
            e.printStackTrace();
        }

        //initiate to zero to test first
        for (int i = 0; i < numSkyDigits; i++) {//sets all to 0, to make sure not null
            SkyDigits[i] = sDigits[0];
            ledColor = ColorUtil.CYAN; //color of numbers
        }
    }

    //this will set the heading of objects
    public void setCurrentHeadingDirection() {
        SkyDigits[0] = sDigits[0];

    }

    public void setLedColor(int ledColor) {
        this.ledColor = ledColor;
    }

    public void startHeadingComponent() {
        getComponentForm().registerAnimated(this);
    }

    public void stopHeadingComponent() {
        getComponentForm().deregisterAnimated(this);
    } //renamed this so it wasn't confused with the other start method in AppMain

    public void laidOut() {
        this.startHeadingComponent(); //this starts the clock only need to call start once
    }
    //registers the form after call start

    public boolean animate() {
        setCurrentHeadingDirection(); //this will set the heading
        return true;
    }

    protected Dimension calcPreferredSize() { //depends on layout using in our form
        return new Dimension(sDigits[0].getWidth() * numSkyDigits, sDigits[0].getHeight());
    }


    public void paint(Graphics g) {
        super.paint(g); //parent paint method
        final int COLOR_PAD = 1; //avoid bleed over, current rectangle slightly smaller images of clock

        int digitWidth = SkyDigits[0].getWidth(); //makes digit width size of one digit
        int digitHeight = SkyDigits[0].getHeight();
        int clockWidth = numSkyDigits * digitWidth;

        float scaleFactor = Math.min(
                getInnerHeight() / (float) digitHeight, // finds inner height
                getInnerWidth() / (float) clockWidth);

        int displayDigitWidth = (int) (scaleFactor * digitWidth);
        int displayDigitHeight = (int) (scaleFactor * digitHeight);
        int displayClockWidth = displayDigitWidth * numSkyDigits;

        int displayX = getX() + (getWidth() - displayClockWidth) / 2;  //centers clock
        int displayY = getY() + (getHeight() - displayDigitHeight) / 2;

        g.setColor(ColorUtil.BLACK);
        g.fillRect(getX(), getY(), getWidth(), getHeight());
        g.setColor(ledColor);
        g.fillRect(displayX + COLOR_PAD,
                displayY + COLOR_PAD,
                displayClockWidth - COLOR_PAD * 2,
                displayDigitHeight - COLOR_PAD * 2);
        for (int digitIndex = 0; //works through images to draw it
             digitIndex < numSkyDigits;
             digitIndex++) {
            g.drawImage
                    (SkyDigits[digitIndex],
                            displayX + digitIndex * displayDigitWidth,
                            displayY,
                            displayDigitWidth,
                            displayDigitHeight);

        }
    }
}

package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import com.codename1.ui.Container;

//this will display game contents in the middle of game screen
public class MapView extends Container {

    private GameObjectCollection gameObjects;
    private Point point;
    private Point pointSky;
   //private Point bird;
    //private Point pointBlimp;
    private final GameWorld gw;
   // private Bird bird = new Bird(ColorUtil.rgb(255, 4, 5), 500, 600, 600);
 //   private RefuelingBlimp blimp = new RefuelingBlimp();

   


    //this is a reference to the GameWorld
    public MapView(GameWorld gw){
        this.gw = gw;
       // gameObjects = gw.getGameObjects();
    }

    //this will update the map objects
    public void update(){
        repaint();
    }

    @Override  //this will override the paint method
    public void paint(Graphics g) {
        super.paint(g);
        point = new Point(this.getX(), this.getY());

        for(int i = 0; i < gw.getGameObjectCollectionList().size(); i++) {
            gw.getGameObjectCollectionList().get(i).draw(g, point);
        }

    }



    }





package org.csc133.a2;



public abstract class MoveableObjects extends GameObject {
    private int heading;
    private int speed;

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getHeading() {
        return heading;
    }

    public void setHeading(int heading) {
        this.heading = heading;
    }

    public void moveObjects(MapView gameMap) {
        double changeInX;
        double changeInY;

        double theta = Math.toRadians(90 - heading);

        changeInX = Math.cos(theta) * speed;
        changeInY = Math.sin(theta) * speed;

        if (getXLocation() > gameMap.getWidth()) {
            setHeading(270);
        }
        if (getYLocation() >= gameMap.getHeight()) {
            setHeading(180);
        }
        if (getXLocation() < 0) {
            setHeading(90);
        }
        //if the y axis location of object is out of bounds rotate 360 deg
        if (getYLocation() < 0) {
            setHeading(360);
        }

        this.setXLocation(getXLocation() + changeInX);
        this.setYLocation(getYLocation() + changeInY);


        //this.setLocationOfObject(getXLocation() + changeInX, getYLocation()+changeInY);
    }

}



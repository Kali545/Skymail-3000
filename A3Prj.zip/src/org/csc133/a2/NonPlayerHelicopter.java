package org.csc133.a2;


import com.codename1.ui.Dialog;

//three instances near first skyscraper (at least several lengths away)
public class NonPlayerHelicopter extends Helicopter{


    public NonPlayerHelicopter(int size, double x, double y) {
        super(size, x, y);
    }

    //this will update the damage from helicopter collision
    public void damage(){

    }

     //this will output when the nph has won
    public int getLastSkyScraperReached() {
        //if(lastSkyScraperReached == greatestSkyScraper){
        Dialog.show("Game Over", "Non Player helicopter has reached" +
                " the last skyscrapper");

   // }
        return 0;
    }



}

package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;


public class RefuelingBlimp extends GameObject implements IDrawable {
    private int capacity = 0; //this is proportional to it's size

    public RefuelingBlimp() {

        setSize(getRandomInt(50, 5));
        setMyColor(ColorUtil.rgb(43,225, 0));
        capacity = (this.getSize()); //each refueling blimp's capacity is it's size
        setXLocation(getRandomDouble(XBoundary));
        setYLocation(getRandomDouble(YBoundary));

    }

    @Override
    public void setXLocation(double xlocal) {
        super.setXLocation(xlocal);
    }

    @Override
    public double getYLocation() {
        return super.getYLocation();
    }

    public void emptyBlimp() {//this is going to be my method to handle the fuel capacity of blimp
    }

    public void draw(Graphics g, Point containerOrigin) {

            g.setColor(this.getMyColor());

            g.drawArc(containerOrigin.getX()+(int)getXLocation(), containerOrigin.getY()+(int)getYLocation(), getSize()*2,getSize(), 0, 360);
            g.setColor(ColorUtil.GRAY);
    }

    @Override
    public boolean collidesWith(GameObject otherObject) {
        return false;
    }

    @Override
    public void handleCollision(GameObject otherObject) {

    }
}
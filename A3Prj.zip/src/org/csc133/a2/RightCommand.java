package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Image;
import com.codename1.ui.events.ActionEvent;

public class RightCommand extends Command {
    private GameWorld gameRight;
    public RightCommand(GameWorld gw){
        super("");
        this.gameRight = gw;

    }
    public void actionPerformed(ActionEvent event){
        gameRight.turnRight();


    }


}

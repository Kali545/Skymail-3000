package org.csc133.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import com.codename1.ui.Image;

import java.io.IOException;


public class SkyScraper extends GameObject {
    private int sequenceNumber;
   private int NOTTOUCHED = 0; //if the skyscraper has not been touched
    private int TOUCHED = 1; // if it has been touched it will change color
    private boolean hasTouched;

    Image nonActivateSkyScraperImage[] = new Image[10];
    Image skyScraperImage[] = new Image[20];

    public SkyScraper(int size, int sequenceNumber){
       setXLocation(getRandomDouble(XBoundary));
       setYLocation(getRandomDouble(YBoundary));
        setSize(size);
        NOTTOUCHED = ColorUtil.rgb(0, 128, 0); //start green
        TOUCHED = ColorUtil.rgb(255,0,0); //turns red when pass or "touch"
        super.setMyDefaultColor(TOUCHED);
        this.sequenceNumber = sequenceNumber;
        hasTouched = false;  //not touched changed when heli reaches it
        try{
            nonActivateSkyScraperImage[0] = Image.createImage("/skyscraper0.png");
            nonActivateSkyScraperImage[1] = Image.createImage("/skyscraper1.png");
            nonActivateSkyScraperImage[2] = Image.createImage("/skyscraper2.png");
            nonActivateSkyScraperImage[3] = Image.createImage("/skyscraper3.png");
            nonActivateSkyScraperImage[4] = Image.createImage("/skyscraper4.png");
            nonActivateSkyScraperImage[5] = Image.createImage("/skyscraper5.png");
            nonActivateSkyScraperImage[6] = Image.createImage("/skyscraper6.png");
            nonActivateSkyScraperImage[7] = Image.createImage("/skyscraper7.png");
            nonActivateSkyScraperImage[8] = Image.createImage("/skyscraper8.png");
            nonActivateSkyScraperImage[9] = Image.createImage("/skyscraper9.png");


        }catch (IOException e ){e.printStackTrace();}
    }


    public int getSequenceNumber(){
        return sequenceNumber;
    }

    public void draw(Graphics g, Point containerOrigin){
        if(hasTouched == true){
            g.setColor(TOUCHED);
        }
        g.drawImage(nonActivateSkyScraperImage[0], containerOrigin.getX() + (int) this.getXLocation(),
                containerOrigin.getY() + (int) this.getYLocation(), this.getSize(), this.getSize());
        //g.drawRect((int)point.getX()+ (int)getXLocation(), (int)point.getY() + (int)getYLocation(),getSize(),getSize());

    }


    //this will output to the console
    public String toString(){
        String string = "NULL";
        System.out.println("This is the output");
        return string;
    }

    @Override
    public boolean collidesWith(GameObject otherObject) {
        return false;
    }

    @Override
    public void handleCollision(GameObject otherObject) {

    }
}
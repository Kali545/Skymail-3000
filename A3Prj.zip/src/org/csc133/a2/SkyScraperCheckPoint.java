package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Image;

public class SkyScraperCheckPoint extends Command { //this will check the last sky scraper
    public SkyScraperCheckPoint(String command, Image icon, int id) {
        super(command, icon, id);
    }
    public void checkSkyScraper(){
        //currentScraper = heli.getLastSkyScraperReached();
        //add a form here

    }
}

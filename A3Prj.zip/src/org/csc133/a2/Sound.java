package org.csc133.a2;

import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;
import java.io.InputStream;

import java.io.IOException;

public class Sound {

    private Media m;
    public Sound(String fileName){
        try{ m = MediaManager.createMedia(Display.getInstance()
                .getResourceAsStream(getClass(),"/" + fileName),"audio/wav");
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }
    public void play(){
        m.setTime(0);
        m.play();
    }
}
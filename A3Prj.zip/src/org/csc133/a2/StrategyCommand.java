package org.csc133.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;

public class StrategyCommand extends Command implements ActionListener {
    private GameWorld g;
    public StrategyCommand(GameWorld gw) {
        super("New Strategy :");
    }

    public void actionPerformed(ActionEvent event){
        //g.pause();
        Command cancelAction = new Command("Cancel");
        Command command = Dialog.show("Change Strategy:", "type of strategy", cancelAction);
    }
}

